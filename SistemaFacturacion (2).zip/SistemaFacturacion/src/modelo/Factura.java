package factura;

import modelo.Cliente;
import modelo.Producto;
import java.util.ArrayList;
import java.util.List;

public class Factura {
    public static final double IVA = 0.13;

    private long numero;
    private final Cliente cliente;
    private final List<Producto> productos = new ArrayList<>();
    private final List<Integer> cantidades = new ArrayList<>();

    public Factura(Cliente cliente) { this.cliente = cliente; }

    public void setNumero(long n){ this.numero = n; }
    public long getNumero(){ return numero; }
    public Cliente getCliente(){ return cliente; }
    public List<Producto> getProductos(){ return productos; }
    public List<Integer> getCantidades(){ return cantidades; }

    public void add(Producto p, int cant){ productos.add(p); cantidades.add(cant); }

    public double getSubTotal(){
        double s=0; for (int i=0;i<productos.size();i++) s += productos.get(i).getPrecio()*cantidades.get(i);
        return s;
    }
    public double getIva(){ return getSubTotal()*IVA; }
    public double getTotal(){ return getSubTotal()+getIva(); }

    public String resumenTexto(){
        StringBuilder sb = new StringBuilder();
        sb.append("FONDO MARINO - FACTURA\n");
        sb.append("Número: ").append(numero).append("\n");
        sb.append("Cliente: ").append(cliente.getNombre()).append("  Cédula: ").append(cliente.getCedula()).append("\n");
        sb.append("Tel: ").append(cliente.getTelefono()).append("  Dir: ").append(cliente.getDireccion()).append("\n");
        sb.append("----------------------------------------------\n");
        sb.append(String.format("%-10s %-24s %6s %10s %10s\n", "Código","Producto","Cant","Precio","Subtot"));
        for (int i=0;i<productos.size();i++){
            Producto p = productos.get(i); int c = cantidades.get(i);
            sb.append(String.format("%-10s %-24s %6d %10.2f %10.2f\n",
                    p.getCodigo(), p.getNombre(), c, p.getPrecio(), p.getPrecio()*c));
        }
        sb.append("----------------------------------------------\n");
        sb.append(String.format("SUBTOTAL: %.2f\n", getSubTotal()));
        sb.append(String.format("IVA 13%%: %.2f\n", getIva()));
        sb.append(String.format("TOTAL  : %.2f\n", getTotal()));
        return sb.toString();
}
}