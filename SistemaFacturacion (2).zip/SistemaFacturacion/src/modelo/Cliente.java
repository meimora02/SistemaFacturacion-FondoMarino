package modelo;

public class Cliente extends Persona {
    private final String direccion;

    public Cliente(String nombre, String cedula, String telefono, String direccion) {
        super(nombre, cedula, telefono);
        this.direccion = direccion;
    }
    public String getDireccion() { return direccion; }

    @Override public String toString() {
        return getCedula()+" | "+getNombre()+" | "+getTelefono()+" | "+direccion;
}
}