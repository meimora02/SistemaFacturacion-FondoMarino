package vista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.File;
import java.sql.*;

public class VentanaSistema extends JFrame {

    // ====== CONFIG BD (tus datos) ======
    private static final String URL  = "jdbc:mysql://localhost:3306/facturacion?useUnicode=true&characterEncoding=UTF-8&serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASS = "Fernandito";

    // --- Clientes
    private final JTextField cNom = new JTextField(16);
    private final JTextField cCed = new JTextField(16);
    private final JTextField cTel = new JTextField(16);
    private final JTextField cDir = new JTextField(16);

    // --- Inventario
    private final DefaultTableModel modeloInv =
            new DefaultTableModel(new Object[]{"Código","Nombre","Cant","Precio"}, 0);
    private final JTable tablaInv = new JTable(modeloInv);
    private final JSpinner spCant = new JSpinner(new SpinnerNumberModel(1,1,999,1));

    // --- Factura
    private final JTextField fCed = new JTextField(14);
    private final DefaultTableModel modeloFac =
            new DefaultTableModel(new Object[]{"Código","Nombre","Cant","Precio","Línea"}, 0);
    private final JTable tablaFac = new JTable(modeloFac);
    private final JLabel lSub = new JLabel("0.00");
    private final JLabel lIva = new JLabel("0.00");
    private final JLabel lTot = new JLabel("0.00");

    public VentanaSistema(){
        super("Sistema de Facturación");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(820, 520);
        setLocationRelativeTo(null);

        JButton bRed = new JButton("Probar redes (socket)");
        bRed.addActionListener(e -> JOptionPane.showMessageDialog(this, Sistema.probarRedes()));
        JPanel top = new JPanel(new FlowLayout(FlowLayout.RIGHT)); top.add(bRed);

        JTabbedPane tabs = new JTabbedPane();
        tabs.add("Clientes", panelClientes());
        tabs.add("Inventario", panelInventario());
        tabs.add("Facturación", panelFactura());

        setLayout(new BorderLayout());
        add(top, BorderLayout.NORTH);
        add(tabs, BorderLayout.CENTER);

        cargarInventarioBD(); // primera carga
    }

    // ==================== CLIENTES ====================
    private JPanel panelClientes(){
        JPanel p = new JPanel(new BorderLayout(8,8));

        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(5,8,5,8); g.fill = GridBagConstraints.HORIZONTAL;

        g.gridx=0; g.gridy=0; form.add(new JLabel("Nombre:"), g);   g.gridx=1; form.add(cNom, g);
        g.gridx=0; g.gridy=1; form.add(new JLabel("Cédula:"), g);   g.gridx=1; form.add(cCed, g);
        g.gridx=0; g.gridy=2; form.add(new JLabel("Teléfono:"), g); g.gridx=1; form.add(cTel, g);
        g.gridx=0; g.gridy=3; form.add(new JLabel("Dirección:"), g);g.gridx=1; form.add(cDir, g);

        JButton bGuardar = new JButton("Guardar (BD)");
        JButton bListar  = new JButton("Listar (BD)");
        JPanel botones = new JPanel(); botones.add(bGuardar); botones.add(bListar);

        bGuardar.addActionListener(this::guardarCliente);
        bListar.addActionListener(this::listarClientes);

        p.add(form, BorderLayout.CENTER);
        p.add(botones, BorderLayout.SOUTH);
        return p;
    }

    private void guardarCliente(ActionEvent e){
        String nom=cNom.getText().trim(), ced=cCed.getText().trim(), tel=cTel.getText().trim(), dir=cDir.getText().trim();
        if(nom.isEmpty()||ced.isEmpty()||tel.isEmpty()||dir.isEmpty()){ JOptionPane.showMessageDialog(this,"Complete todo"); return; }
        Sistema.guardarCliente(ced, nom, tel, dir);
        cNom.setText(""); cCed.setText(""); cTel.setText(""); cDir.setText("");
        JOptionPane.showMessageDialog(this,"Cliente guardado");
    }

    private void listarClientes(ActionEvent e){
        ResultSet rs = Sistema.listarClientes(); if (rs==null) return;
        StringBuilder sb = new StringBuilder("Clientes:\n\n");
        try {
            while (rs.next()){
                sb.append(rs.getString("cedula")).append(" | ")
                  .append(rs.getString("nombre")).append(" | ")
                  .append(rs.getString("telefono")).append(" | ")
                  .append(rs.getString("direccion")).append("\n");
            }
            JOptionPane.showMessageDialog(this, sb.toString());
        } catch (Exception ex){ JOptionPane.showMessageDialog(this,"Error: "+ex.getMessage()); }
        finally { close(rs); }
    }

    // ==================== INVENTARIO ====================
    private JPanel panelInventario(){
        JPanel p = new JPanel(new BorderLayout(6,6));
        JPanel south = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton bRef = new JButton("Refrescar (BD)");
        south.add(new JLabel("Cantidad:")); south.add(spCant);
        JButton bAdd = new JButton("Agregar a factura");
        south.add(bAdd); south.add(bRef);

        bRef.addActionListener(e -> cargarInventarioBD());
        bAdd.addActionListener(e -> agregarLineaDesdeInventario());

        p.add(new JScrollPane(tablaInv), BorderLayout.CENTER);
        p.add(south, BorderLayout.SOUTH);
        return p;
    }

    private void cargarInventarioBD(){
        modeloInv.setRowCount(0);
        try (Connection con = DriverManager.getConnection(URL, USER, PASS);
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT codigo,nombre,precio FROM productos ORDER BY codigo")) {

            while (rs.next()){
                String cod = rs.getString("codigo");
                String nom = rs.getString("nombre");
                double pre = rs.getDouble("precio");
                modeloInv.addRow(new Object[]{cod, nom, 1, pre}); // Cant = 1 por defecto
            }
        } catch (SQLException ex){
            JOptionPane.showMessageDialog(this, "BD inventario: "+ex.getMessage());
        }
    }

    private void agregarLineaDesdeInventario(){
        int i = tablaInv.getSelectedRow();
        if (i<0){ JOptionPane.showMessageDialog(this,"Seleccione un producto"); return; }
        int cant = (int) spCant.getValue();
        String cod = modeloInv.getValueAt(i,0).toString();
        String nom = modeloInv.getValueAt(i,1).toString();
        double precio = Double.parseDouble(modeloInv.getValueAt(i,3).toString());
        double linea = Math.round(precio*cant*100.0)/100.0;
        modeloFac.addRow(new Object[]{cod, nom, cant, precio, linea});
        recalcular();
    }

    // ==================== FACTURACIÓN ====================
    private JPanel panelFactura(){
        JPanel p = new JPanel(new BorderLayout(6,6));

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.add(new JLabel("Cédula cliente:")); top.add(fCed);
        JButton bLimpiar = new JButton("Limpiar líneas");
        top.add(bLimpiar);
        bLimpiar.addActionListener(e -> { modeloFac.setRowCount(0); recalcular(); });

        JPanel tot = new JPanel(new GridLayout(1,6,8,8));
        tot.add(new JLabel("Subtotal:")); tot.add(lSub);
        tot.add(new JLabel("IVA 13%:")); tot.add(lIva);
        tot.add(new JLabel("TOTAL:"));   tot.add(lTot);

        JButton bGen = new JButton("Generar TXT");
        bGen.addActionListener(e -> generarFactura());

        JPanel south = new JPanel(new BorderLayout());
        south.add(tot, BorderLayout.WEST);
        south.add(bGen, BorderLayout.EAST);

        p.add(top, BorderLayout.NORTH);
        p.add(new JScrollPane(tablaFac), BorderLayout.CENTER);
        p.add(south, BorderLayout.SOUTH);
        return p;
    }

    private void recalcular(){
        double sub=0;
        for (int r=0;r<modeloFac.getRowCount();r++){
            sub += Double.parseDouble(modeloFac.getValueAt(r,4).toString());
        }
        double iva = Math.round(sub*0.13*100.0)/100.0;
        double tot = Math.round((sub+iva)*100.0)/100.0;
        lSub.setText(String.format("%.2f", sub));
        lIva.setText(String.format("%.2f", iva));
        lTot.setText(String.format("%.2f", tot));
    }

    private void generarFactura(){
        String ced = fCed.getText().trim();
        if (ced.isEmpty()){ JOptionPane.showMessageDialog(this,"Ingrese cédula de cliente"); return; }
        if (modeloFac.getRowCount()==0){ JOptionPane.showMessageDialog(this,"Agregue líneas"); return; }

        java.util.List<Sistema.Linea> lineas = new java.util.ArrayList<>();
        for (int r=0;r<modeloFac.getRowCount();r++){
            String cod = modeloFac.getValueAt(r,0).toString();
            String nom = modeloFac.getValueAt(r,1).toString();
            int cant   = Integer.parseInt(modeloFac.getValueAt(r,2).toString());
            double pre = Double.parseDouble(modeloFac.getValueAt(r,3).toString());
            lineas.add(new Sistema.Linea(cod, nom, cant, pre));
        }
        File f = Sistema.generarFacturaTxt(ced, lineas);
        if (f!=null) JOptionPane.showMessageDialog(this, "Factura creada:\n"+f.getAbsolutePath());
    }

    private void close(ResultSet rs){
        try {
            Statement st = rs.getStatement();
            Connection cn = st.getConnection();
            rs.close(); st.close(); cn.close();
        } catch (Exception ignore) {}
    }

    public static void main(String[] args){
        SwingUtilities.invokeLater(() -> new VentanaSistema().setVisible(true));
}
}