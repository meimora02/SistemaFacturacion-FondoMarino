package vista;

import java.io.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class Sistema {

    static final String URL  = "jdbc:mysql://localhost:3306/facturacion?useUnicode=true&characterEncoding=UTF-8&serverTimezone=UTC";
    static final String USER = "root";
    static final String PASS = "Fernandito";
    static final double IVA  = 0.13;

    static Connection con() throws SQLException { return DriverManager.getConnection(URL, USER, PASS); }

    // --- Clientes (BD)
    public static void guardarCliente(String ced, String nom, String tel, String dir){
        String sql = "INSERT INTO clientes(cedula,nombre,telefono,direccion) VALUES(?,?,?,?) " +
                     "ON DUPLICATE KEY UPDATE nombre=VALUES(nombre),telefono=VALUES(telefono),direccion=VALUES(direccion)";
        try (Connection c = con(); PreparedStatement ps = c.prepareStatement(sql)){
            ps.setString(1, ced); ps.setString(2, nom); ps.setString(3, tel); ps.setString(4, dir);
            ps.executeUpdate();
        } catch (SQLException e){ msg("BD clientes: "+e.getMessage()); }
    }
    public static ResultSet listarClientes(){
        try {
            Connection c = con();
            Statement st = c.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
            return st.executeQuery("SELECT cedula,nombre,telefono,direccion FROM clientes ORDER BY cedula");
        } catch (SQLException e){ msg("BD clientes: "+e.getMessage()); return null; }
    }

    // --- Productos (BD)
    public static ResultSet listarProductos(){
        try {
            Connection c = con();
            Statement st = c.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
            return st.executeQuery("SELECT codigo,nombre,cantidad,precio FROM productos ORDER BY codigo");
        } catch (SQLException e){ msg("BD productos: "+e.getMessage()); return null; }
    }

    // --- Factura: TXT simple
    public static File generarFacturaTxt(String cedulaCliente, List<Linea> lineas){
        Map<String,String> cli = buscarCliente(cedulaCliente);
        if (cli == null) { msg("Cliente no encontrado."); return null; }
        BigDecimal sub = BigDecimal.ZERO;
        for (Linea l : lineas){
            BigDecimal linea = BigDecimal.valueOf(l.precio).multiply(BigDecimal.valueOf(l.cantidad));
            sub = sub.add(linea);
        }
        BigDecimal iva = sub.multiply(BigDecimal.valueOf(IVA)).setScale(2, RoundingMode.HALF_UP);
        BigDecimal total = sub.add(iva).setScale(2, RoundingMode.HALF_UP);

        String num = DateTimeFormatter.ofPattern("yyyyMMddHHmmss").format(LocalDateTime.now());
        StringBuilder sb = new StringBuilder();
        sb.append("FACTURA #").append(num).append("\n");
        sb.append("Cliente: ").append(cli.get("nombre")).append("  Cedula: ").append(cli.get("cedula")).append("\n");
        sb.append("Telefono: ").append(cli.get("telefono")).append("  Direccion: ").append(cli.get("direccion")).append("\n\n");
        sb.append(String.format("%-10s %-32s %8s %10s %10s%n","Codigo","Nombre","Cant","Precio","Linea"));
        for (Linea l : lineas){
            double linea = red(l.precio * l.cantidad);
            sb.append(String.format("%-10s %-32s %8d %10.2f %10.2f%n", l.codigo, l.nombre, l.cantidad, l.precio, linea));
        }
        sb.append("\n");
        sb.append(String.format("SUBTOTAL: %.2f   IVA(13%%): %.2f   TOTAL: %.2f%n", sub, iva, total));

        try {
            File out = new File(new File(System.getProperty("user.home"), "Documents"), "Factura_"+num+".txt");
            try (Writer w = new OutputStreamWriter(new FileOutputStream(out), StandardCharsets.UTF_8)){
                w.write(sb.toString());
            }
            return out;
        } catch (IOException e){ msg("Archivo: "+e.getMessage()); return null; }
    }

    static double red(double v){ return Math.round(v*100.0)/100.0; }

    static Map<String,String> buscarCliente(String ced){
        try (Connection c = con();
             PreparedStatement ps = c.prepareStatement("SELECT cedula,nombre,telefono,direccion FROM clientes WHERE cedula=?")){
            ps.setString(1, ced);
            try (ResultSet rs = ps.executeQuery()){
                if (rs.next()){
                    Map<String,String> m = new HashMap<>();
                    m.put("cedula", rs.getString(1));
                    m.put("nombre", rs.getString(2));
                    m.put("telefono", rs.getString(3));
                    m.put("direccion", rs.getString(4));
                    return m;
                }
            }
        } catch (SQLException e){ msg("BD buscar cliente: "+e.getMessage()); }
        return null;
    }

    // --- Red (socket local)
    public static String probarRedes(){
        final int PORT = 6020;
        String[] resp = {""};

        Thread server = new Thread(() -> {
            try (ServerSocket ss = new ServerSocket(PORT);
                 Socket s = ss.accept();
                 BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
                 PrintWriter out = new PrintWriter(new OutputStreamWriter(s.getOutputStream(), StandardCharsets.UTF_8), true)) {
                String cmd = in.readLine();
                out.println("OK: "+cmd);
            } catch (IOException ignored) {}
        });
        server.start();

        try {
            Thread.sleep(150);
            try (Socket c = new Socket("127.0.0.1", PORT);
                 BufferedReader in = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8));
                 PrintWriter out = new PrintWriter(new OutputStreamWriter(c.getOutputStream(), StandardCharsets.UTF_8), true)) {
                out.println("Ping desde cliente");
                resp[0] = in.readLine();
            }
            server.join();
        } catch (Exception e){ resp[0] = "Error: "+e.getMessage(); }

        return resp[0].isEmpty() ? "Sin respuesta" : resp[0];
    }

    public static class Linea {
        public final String codigo, nombre;
        public final int cantidad;
        public final double precio;
        public Linea(String codigo, String nombre, int cantidad, double precio){
            this.codigo=codigo; this.nombre=nombre; this.cantidad=cantidad; this.precio=precio;
        }
    }

    static void msg(String s){ System.out.println(s); }
}